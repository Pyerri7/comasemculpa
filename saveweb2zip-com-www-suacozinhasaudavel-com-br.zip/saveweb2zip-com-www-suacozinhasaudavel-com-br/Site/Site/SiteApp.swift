//
//  SiteApp.swift
//  Site
//
//  Created by Pyerri Eduardo Costa  on 07/09/25.
//

import SwiftUI

@main
struct SiteApp: App {
    var body: some Scene {
        DocumentGroup(newDocument: SiteDocument()) { file in
            ContentView(document: file.$document)
        }
    }
}
